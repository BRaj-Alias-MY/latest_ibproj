import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import {PaymentsService} from '../services/payments.service';
import { ValidationService } from '../../../services/validation.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer } from '../../../childmessagerender.component';

@Component({
  selector: 'app-chequemanagement',
  templateUrl: './chequemanagement.component.html',
  styleUrls: ['./chequemanagement.component.css']
})
export class ChequemanagementComponent implements OnInit {
  up_val: any;
	index = '';
	rpt_btn_name = '';
	update;
	items;
	btn_update = 'Update';
	btn_add = 'Add';
	access;
	IsForUpdate: boolean = false;
	newItem: any = {};
	updatedItem;
	btn_name: string;
	current_page: number;
	start_record: number;
	pages;
	total_records: number;
	grid_tab;
	sh_add: boolean;
	togel_name: string;
	view_item: any;
	private gridOptions: GridOptions;
	private gridApi;
	private gridColumnApi;

	private columnDefs;
	private rowData;
	private context;
	private frameworkComponents;


  constructor(private fb: FormBuilder, private route: Router, private api: PaymentsService) {
    this.gridOptions = <GridOptions>{
			paginationNumberFormatter: function(params) {
				return '[' + params.value.toLocaleString() + ']';
			}
		};
		this.columnDefs = [
      { headerName: 'Cheque Number', field: 'chequeNo' },
      { headerName: 'Status', field: 'status' },

			{
				headerName: 'Action',
				cellRenderer: 'childMessageRenderer',
				colId: 'params',
				value: 'id'
			}
		];
		this.frameworkComponents = {
			childMessageRenderer: ChildMessageRenderer
		};
		this.context = { componentParent: this };
   }

  onEditClick(id) {
		console.log(id);
	}

	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;

		params.api.sizeColumnsToFit();
	}
  ngOnInit() {
    this.grid_tab = [];
    this.sh_add = false;
		// this.togel_name = 'Add';
		this.btn_name = 'Save';
		this.view_item = [];
		this.current_page = 1;
		this.pages = [];
		this.start_record = 1;
		this.update = false;
		this.access = {addAccess: 0, editAccess: 0,deleteAccess:0,gridAccess:0};
		this.rpt_btn_name = this.btn_add;
		this.up_val = '';

		this.grid();
 
  }

  chequemgmtForm = this.fb.group({
		id:[],
    chequeClearedDate: [''],
    chequeNo:[''],
    status: ['']
    });

    methodFromParentEdit(cell, valls) {
      //Swal("Edit");
      console.log(valls.id);
      this.EditItem(valls.id);
    }
  
    get_item_data_with_id(item_id) {
      for (let i = 0; i < this.grid_tab.length; i++) {
        if (this.grid_tab[i].id == item_id) {
          return this.grid_tab[i];
        }
      }
    }
    methodFromParentView(cell, valls) {
      // Swal("View");
      console.log(valls);
      this.ViewItem(valls.id);
    }
  
    View(item_id){
      var x = document.getElementById("add");
      if (x.style.display === "none") {
    } else {
      x.style.display = "none";
    }
    }

    EditItem(item_id) {
      // console.log(item_id);
      this.sh_add = true;
      this.togel_name = 'Close';
      this.btn_name = 'Update';
      this.chequemgmtForm.patchValue(this.get_item_data_with_id(item_id));
    
      //console.log(this.domainForm);
    }
  
    ViewItem(item_id) {
      this.view_item.push(this.get_item_data_with_id(item_id));
      //console.log(this.view_item);
      this.sh_add = false;
      // this.togel_name = 'Add';
    }
  
    back_view() {
      this.view_item = [];
    }

    add_togel(){
      this.sh_add = this.sh_add ? false : true;
      this.togel_name = this.togel_name == 'Add' ? 'Close' : '';
      this.btn_name = 'Save';
      this.chequemgmtForm.patchValue({id: '', chequeClearedDate: '',chequeNo:'',status:''});
      
       }

    onSubmit(){
      let data = this.chequemgmtForm.value;
       console.log(data);
       this.api.save_chequedetails(data).subscribe((res) => {
				if (res.status) {
					this.chequemgmtForm.patchValue({id:'', chequeClearedDate: '',chequeNo:'',status:'' });
           this.grid();
          this.sh_add=false;
					 Swal.fire('Success..', 'Record insert/updated successfully.', 'success');
					// this.clear_fields();
				} else {
					//this.loading.hide();
					Swal.fire('Oops...', 'Something went wrong!', 'error');
				}
			}); 
    }

    grid() {
      //console.log(this.current_page);
      this.api.get_cheque_details().subscribe((data) => {
        this.access = data.access;
        console.log(this.access);
       if (this.access && this.access.gridAccess) {
          this.grid_tab = data.data;
          console.log(this.grid_tab);
        }
        //this.sh_add = false;
      //  this.togel_name = 'Add';
       // this.btn_name = 'Save';
        //this.loading.hide();
       this.view_item = [];
      });
     
    }

}
