export class Question {

    id: number;
    InterviewId: number;
    uid: string;
    answer: string;
    videoURL: string;
    userId: number;
    status: number;
    time_taken: string;
    q_time: number;
}