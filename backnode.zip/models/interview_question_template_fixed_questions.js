/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('interview_question_template_fixed_questions', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    interviewQuestionTemplateId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview_question_template',
        key: 'id'
      }
    },
    questionId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'questions',
        key: 'id'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview_question_template_fixed_questions'
  });
};
