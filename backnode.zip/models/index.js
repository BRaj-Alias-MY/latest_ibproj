'use strict';

const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');
const basename = path.basename(__filename);
const env = process.env.NODE_ENV || 'development';
const config = require(__dirname + '/../config/config.json')[env];
const db = {};
const JSON = require('circular-json');

let sequelize;
if (config.use_env_variable) {
  sequelize = new Sequelize(process.env[config.use_env_variable], config);
} else {
  sequelize = new Sequelize(config.database, config.username, config.password, config);
}

sequelize.addHook('afterCreate',
  function(model, options, done) {
    let key = model.constructor.name;
    let user = model.auth ? model.auth : 0;
    if(user>0){
      let created = new Date();
      sequelize.query("INSERT INTO `logs`(`tableName`, `action`, `remarks`, `respectiveId`, `userId`,createdAt,updatedAt) VALUES ('"+key+"','insert','"+JSON.stringify(model)+"','"+model.id+"','"+user+"',now(),now())").spread((results, metadata) => {
        return true;
      });
    }
    return false;
});

sequelize.addHook('afterUpdate',
  function(model, options) {
    console.log(model);
    let key = model.constructor.name;
    let user = model.auth ? model.auth : 0;
    if(user>0){
      sequelize.query("INSERT INTO `logs`(`tableName`, `action`, `remarks`, `respectiveId`, `userId`,createdAt,updatedAt) VALUES ('"+key+"','update','"+JSON.stringify(model)+"','"+model.id+"','"+user+"',now(),now())").spread((results, metadata) => {
        return true;
      });
    }
    return false;
});

sequelize.addHook('afterBulkUpdate',
  function(options) {
    let key = options.model.name;
    let user = options.auth ? options.auth : 0;
    if(user>0){
      sequelize.query("INSERT INTO `logs`(`tableName`, `action`, `remarks`, `respectiveId`, `userId`,createdAt,updatedAt) VALUES ('"+key+"','update','"+JSON.stringify(options)+"','"+JSON.stringify(options.where)+"','"+user+"',now(),now())").spread((results, metadata) => {
        return true;
      });
    }
    return false;
});

sequelize.addHook('afterBulkCreate',
  function(model,options) {
    let key = options.model.name;
    let user = options.auth ? options.auth : 0;

    let val = [];
    model.forEach((key,value)=>{
      val.push(key.id);
    });
    if(user>0){
      sequelize.query("INSERT INTO `logs`(`tableName`, `action`, `remarks`, `respectiveId`, `userId`,createdAt,updatedAt) VALUES ('"+key+"','insert','"+JSON.stringify(options)+"','"+JSON.stringify(val)+"','"+user+"',now(),now())").spread((results, metadata) => {
        return true;
      });
    }
    return false;
});

sequelize.addHook('beforeBulkDestroy',
  function(options) {
    //console.log(options);
    options.model.findAll({where:options.where}).then(data=>{
      options.model.afterBulkDestroy(function(options) {//hook1
        options.data = data;
      });
    })
});

sequelize.addHook('afterBulkDestroy',
  function(options) {
    //console.log(options);
    let key = options.model.name;
    let user = options.auth ? options.auth : 0;
    if(user>0){
      sequelize.query("INSERT INTO `logs`(`tableName`, `action`, `remarks`, `respectiveId`, `userId`,createdAt,updatedAt) VALUES ('"+key+"','delete','"+JSON.stringify(options.data)+"','"+JSON.stringify(options.where)+"','"+user+"',now(),now())").spread((results, metadata) => {
        return true;
      });
    }
    return false;
});


fs
  .readdirSync(__dirname)
  .filter(file => {
    return (file.indexOf('.') !== 0) && (file !== basename) && (file.slice(-3) === '.js');
  })
  .forEach(file => {
    const model = sequelize['import'](path.join(__dirname, file));
    db[model.name] = model;
  });

Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
