/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('interview_expert_overall_feedback', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    reportPerameterId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'report_perameters',
        key: 'id'
      }
    },
    interviewExpertId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'interview_experts',
        key: 'id'
      }
    },
    review: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    rating: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview_expert_overall_feedback'
  });
};
