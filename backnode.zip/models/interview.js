/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  let interview = sequelize.define('interview', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true
    },
    type: {
      type: DataTypes.ENUM('async','ff'),
      allowNull: false
    },
    domainId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'domain',
        key: 'id'
      }
    },
    interviewId:{
      type: DataTypes.TEXT,
      allowNull: true
    },
    subDomainId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'sub_domains',
        key: 'id'
      }
    },
    expLevelId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'exp_level',
        key: 'id'
      }
    },
    start_date: {
      type: DataTypes.DATE,
      allowNull: false
    },
    end_date: {
      type: DataTypes.DATE,
      allowNull: false
    },
    duration: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    questionCount: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    organizationId: {
      type: DataTypes.INTEGER(11),
      allowNull: true,
      references: {
        model: 'organization_campus',
        key: 'id'
      }
    },
    userId: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      references: {
        model: 'users',
        key: 'id'
      }
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    tableName: 'interview'
  });
  interview.associate = function(models) {
	  interview.hasMany(models.interview_fixed_questions, {foreignKey: 'interviewId', targetKey: 'id'});
  };
  return interview;
};
